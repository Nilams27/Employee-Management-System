UI Versions:
————————————————
Angular - 16.2.0
Node: 20.5.1
npm: 9.8.0
Bootstrap: 5.3.1
Angular Material: 16.2.2


Backend Versions:
————————————————
Java: 17.0.8
Maven: 3.9.4
Spring Boot: 3.1.3
